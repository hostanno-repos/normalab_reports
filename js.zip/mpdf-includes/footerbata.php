<sethtmlpagefooter name="footer" value="on" show-this-page="1" />
<htmlpagefooter name="footer">
    <div style="font-family: 'Times New Roman', Times, serif; font-size: 9px; text-align: center;">
        <img src="images/bata-logo.jpg" alt="" style="width:75px;">
    </div>
</htmlpagefooter>

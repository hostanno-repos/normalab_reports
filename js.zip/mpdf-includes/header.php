<htmlpageheader name="header">
    <div class="header-logo" style="width: 50%;float: left;">
        <img src="./images/logoBez.png" alt="" style="width: 180px;">
    </div>
    <div class="header-info" style="width: 50%;float: right;">
        <p style="font-family: 'Times New Roman', Times, serif;font-size: 11px;text-align: right;margin:0;">"NormaLab" д.о.о., Бања Лука</p>
        <p style="font-family: 'Times New Roman', Times, serif;font-size: 11px;text-align: right;margin:0;">Српска 99, II спрат, 8б</p>
        <p style="font-family: 'Times New Roman', Times, serif;font-size: 11px;text-align: right;margin:0;">office@normalab.ba</p>
        <p style="font-family: 'Times New Roman', Times, serif;font-size: 11px;text-align: right;margin:0;">+387 66 76 67 81</p>
    </div>
</htmlpageheader>
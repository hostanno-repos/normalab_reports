<?php 

$host = "localhost";
$database = "normalab_reports";
$username = "root";
$password = "";

?>
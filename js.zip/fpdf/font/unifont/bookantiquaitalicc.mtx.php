<?php
$name='BookAntiqua-Italic';
$type='TTF';
$desc=array (
  'Ascent' => 923.0,
  'Descent' => -282.0,
  'CapHeight' => 923.0,
  'Flags' => 68,
  'FontBBox' => '[-173 -307 1060 1041]',
  'ItalicAngle' => -9.5,
  'StemV' => 87.0,
  'MissingWidth' => 750.0,
);
$up=-131;
$ut=58;
$ttffile='C:\wamp64\www\normalab\admin\fpdf/font/unifont/BookAntiquaItalicc.ttf';
$originalsize=168002;
$fontkey='dejavu';
?>
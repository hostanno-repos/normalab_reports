<?php
$name='BookAntiqua';
$type='TTF';
$desc=array (
  'Ascent' => 923.0,
  'Descent' => -282.0,
  'CapHeight' => 923.0,
  'Flags' => 4,
  'FontBBox' => '[-136 -311 1154 1036]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 750.0,
);
$up=-131;
$ut=58;
$ttffile='C:\wamp64\www\normalab\admin\fpdf/font/unifont/bookAntiqua.ttf';
$originalsize=174264;
$fontkey='dejavu';
?>
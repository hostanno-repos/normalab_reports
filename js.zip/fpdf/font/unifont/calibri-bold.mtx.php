<?php
$name='Calibri-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 750.0,
  'Descent' => -250.0,
  'CapHeight' => 632.0,
  'Flags' => 262148,
  'FontBBox' => '[-519 -306 1240 971]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 507.0,
);
$up=-113;
$ut=65;
$ttffile='fpdf/font/unifont/calibri-bold.ttf';
$originalsize=848924;
$fontkey='calibri-bold';
?>
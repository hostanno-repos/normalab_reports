<?php
$name='Calibri';
$type='TTF';
$desc=array (
  'Ascent' => 750.0,
  'Descent' => -250.0,
  'CapHeight' => 632.0,
  'Flags' => 4,
  'FontBBox' => '[-503 -307 1240 964]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 507.0,
);
$up=-113;
$ut=65;
$ttffile='fpdf/font/unifont/calibri-regular.ttf';
$originalsize=811412;
$fontkey='calibri-regular';
?>